-- Hospital Appointment and Patient Management System
-- MySQL 8.0+
-- Schema aligned to the existing Java model fields in main.java / HospitalServer.java.
-- This script creates the database structure only; it does not modify or connect Java code.

CREATE DATABASE IF NOT EXISTS hospital_management
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_0900_ai_ci;

USE hospital_management;

CREATE TABLE IF NOT EXISTS patients (
    patient_id INT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    phone VARCHAR(25) NOT NULL,
    email VARCHAR(254) NOT NULL UNIQUE,
    disease VARCHAR(255),
    address VARCHAR(500),
    blood_group VARCHAR(5),
    emergency_contact VARCHAR(25),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS doctors (
    doctor_id INT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    phone VARCHAR(25),
    email VARCHAR(254) UNIQUE,
    specialization VARCHAR(120) NOT NULL,
    department VARCHAR(120) NOT NULL,
    experience INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_doctor_experience CHECK (experience >= 0)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS appointments (
    appointment_id INT PRIMARY KEY,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    appointment_date DATE NOT NULL,
    appointment_time TIME NOT NULL,
    status ENUM('Booked', 'Cancelled', 'Rescheduled') NOT NULL DEFAULT 'Booked',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_appointments_patient
        FOREIGN KEY (patient_id) REFERENCES patients(patient_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_appointments_doctor
        FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    INDEX idx_appointments_patient (patient_id),
    INDEX idx_appointments_doctor_date_time (doctor_id, appointment_date, appointment_time)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS medical_records (
    record_id INT PRIMARY KEY,
    patient_id INT NOT NULL,
    diagnosis TEXT,
    prescription TEXT,
    medical_history TEXT,
    record_date DATE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_medical_records_patient
        FOREIGN KEY (patient_id) REFERENCES patients(patient_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT uq_medical_records_patient UNIQUE (patient_id),
    INDEX idx_medical_records_date (record_date)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS administrators (
    admin_id INT PRIMARY KEY,
    username VARCHAR(80) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Helpful report view
CREATE OR REPLACE VIEW appointment_details AS
SELECT
    a.appointment_id,
    a.patient_id,
    p.name AS patient_name,
    a.doctor_id,
    d.name AS doctor_name,
    d.specialization,
    d.department,
    a.appointment_date,
    a.appointment_time,
    a.status
FROM appointments a
JOIN patients p ON p.patient_id = a.patient_id
JOIN doctors d ON d.doctor_id = a.doctor_id;

-- Quick verification after running this script:
SHOW TABLES;
