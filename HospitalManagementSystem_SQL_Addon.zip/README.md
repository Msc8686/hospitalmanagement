# Hospital Management System — SQL Add-on

This add-on was prepared to match the model fields visible in the public repository:
- `Patient`: patient ID, name, phone, email, disease, address, blood group, emergency contact
- `Doctor`: doctor ID, name, phone, email, specialization, department, experience
- `Appointment`: appointment ID, patient, doctor, date, time, status
- `MedicalRecord`: record ID, patient ID, diagnosis, prescription, medical history, record date
- `Administrator`: admin ID, username, password (stored as a hash in SQL)

## Database choice
MySQL 8.0+.

## Create the schema
1. Install/start MySQL Server and open MySQL Workbench.
2. Open `schema.sql`.
3. Execute the whole script.
4. Confirm that `hospital_management` and its five tables are listed.

You can also run it from a terminal:
```bash
mysql -u root -p < schema.sql
```

## Important compatibility note
The current Java server keeps patients, doctors, appointments, and medical records in Java objects/in-memory collections. Creating these SQL tables alone does **not** make the running app save or read data from MySQL. That requires a small JDBC integration in the Java server (or a separate database service) and a MySQL JDBC driver. I have not altered any existing source files, as requested.

## JDBC dependency (for a future integration)
If you use Maven, add this dependency inside the existing `pom.xml` `<dependencies>` section:
```xml
<dependency>
    <groupId>com.mysql</groupId>
    <artifactId>mysql-connector-j</artifactId>
    <version>9.5.0</version>
</dependency>
```
If this project is not a Maven project, the MySQL Connector/J JAR must be added to the project's classpath instead. Match the driver version to your installed Java runtime and project setup.

## Schema notes
- Foreign keys ensure appointments refer to existing patients and doctors, and records refer to existing patients.
- `medical_records.patient_id` is unique because the current Java code searches for one medical record per patient.
- The administrator table uses `password_hash`; do not store plain-text passwords there.
- The existing Java admin login currently uses a hard-coded sample username/password. This schema does not connect to or replace that login.
- This is a development/college-project schema, not a production healthcare deployment.
